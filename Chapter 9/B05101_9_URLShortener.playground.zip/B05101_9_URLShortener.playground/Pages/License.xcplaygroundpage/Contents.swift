/*:
 
 The license for this document is available [here](License).
 */
